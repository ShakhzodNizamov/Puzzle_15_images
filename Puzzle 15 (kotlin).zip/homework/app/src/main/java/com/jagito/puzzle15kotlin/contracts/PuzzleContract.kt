package com.jagito.puzzle15kotlin.contracts

import com.jagito.puzzle15kotlin.models.Coordinate
import com.jagito.puzzle15kotlin.models.LocalStorage

interface PuzzleContract {
    interface Model {
        val numbers: List<Int>
        val pref: LocalStorage
    }

    interface View {
        fun finishGame()
        fun loadData(data: List<String>)
        fun setElementText(coordinate: Coordinate, s: String)
        fun getElementText(coordinate: Coordinate): String
        fun setScore(score: Int)
        fun showWin(score: Int)
        fun startTimer(base: Long = 0)
        fun getBaseTime(): Long
        fun showConfirmDialog()
        fun hideConfirmDialog()
    }

    interface Presenter {
        fun saveData()
        fun finish()
        fun startGame()
        fun restart()
        fun click(coordinate: Coordinate)
        fun onClickNoInConfirm()
        var space: Coordinate
        var step: Int
    }
}