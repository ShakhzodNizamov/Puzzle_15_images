package com.jagito.puzzle15kotlin.models

data class Coordinate(var x: Int, var y: Int)