package com.jagito.puzzle15kotlin.models

import com.jagito.puzzle15kotlin.contracts.PuzzleContract
import java.util.*

class PuzzleRepository(override val pref: LocalStorage) : PuzzleContract.Model {
    private val list = ArrayList<Int>()

    override val numbers: List<Int>
        get() {
            list.shuffle()
            return checkShuffle(list)
        }

    private fun checkShuffle(list: List<Int>): List<Int> {
        var sum = 0
        for (i in list.indices) {
            for (j in list.size - 1 downTo i + 1) {
                if (list[i] > list[j]) sum++
            }
        }
        return if (sum % 2 == 0) {
            list
        } else checkShuffle(numbers)
    }

    init {
        for (i in 1..15) {
            list.add(i)
        }
    }
}