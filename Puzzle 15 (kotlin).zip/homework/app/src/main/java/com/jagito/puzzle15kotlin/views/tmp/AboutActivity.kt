package com.jagito.puzzle15kotlin.views.tmp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.jagito.puzzle15kotlin.R


class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
    }
}