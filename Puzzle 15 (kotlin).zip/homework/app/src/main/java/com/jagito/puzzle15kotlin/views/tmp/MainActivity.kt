package com.jagito.puzzle15kotlin.views.tmp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.jagito.puzzle15kotlin.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<View>(R.id.main_play).setOnClickListener {
            startActivity(
                Intent(this, GameActivity::class.java)
            )
        }
        findViewById<View>(R.id.main_about).setOnClickListener {
            startActivity(
                Intent(this, AboutActivity::class.java)
            )
        }
        findViewById<View>(R.id.main_exit).setOnClickListener { finishAffinity() }
    }
}
